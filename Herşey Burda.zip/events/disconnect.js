module.exports = client => {
  console.log(`Bağlantın koptu! ${new Date()}`);
};
